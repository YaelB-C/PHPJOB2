<?php
$marque = array("volvo","BMW","Toyota", "Peugeot","Renault",);
$i=0;
foreach ($elem as $marque) {
	echo "Vente de : " . $elem . "<br/>";
}
?>
